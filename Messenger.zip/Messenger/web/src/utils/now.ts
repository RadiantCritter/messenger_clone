export default function now() {
  return Math.floor(Date.now() / 1000);
}
