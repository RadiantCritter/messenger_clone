const wait = (time: number) => new Promise((res) => setTimeout(res, time));

export default wait;
